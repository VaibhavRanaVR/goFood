import React, { useEffect, useState } from "react";
import "./Styles/Registration.css";
import registration from "./Images/registration.jpg";
import TypeWriter from "../../ReusableComponents/TypeWriter";
import Button from "../../ReusableComponents/Button";
import { backendUrl } from "../../backendUrl";
import axios from "axios";

const Registration = () => {
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    address: "",
    password: "",
    role: "user",
  });

  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  function handleChange(e) {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  }

  async function handleSubmit(e) {
    try {
      e.preventDefault();
      let res = await axios.post(`${backendUrl}/auth/register`, formData);
      console.log("Response:", res.data);
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        address: "",
        password: "",
        role: "user",
      });
    } catch (error) {
      console.error("Error:", error);
    }
  }

  return (
    <div className="Registration-Container">
      <div className="text-center">
        <TypeWriter
          textArray={["GOFOOD SIGN UP"]}
          fontSize={windowWidth < 600 ? "1.4em" : "2em"}
          color="black"
        />
      </div>

      <div className="Registration-Content-Container">
        <div className="Registration-Form-Container">
          <form onSubmit={handleSubmit}>
            <div>
              <input
                type="text"
                placeholder="Name"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
              />
            </div>
            <div>
              <input
                type="text"
                placeholder="Email"
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
            </div>
            <div>
              <input
                type="text"
                placeholder="Address"
                name="address"
                value={formData.address}
                onChange={handleChange}
              />
            </div>
            <div>
              <input
                type="number"
                placeholder="Phone-No"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
              />
            </div>
            <div>
              <input
                type="password"
                placeholder="Password"
                name="password"
                value={formData.password}
                onChange={handleChange}
              />
            </div>
            <div>
              <Button text="Register" />
            </div>
          </form>
        </div>
        <div className="Registration-Image-Container">
          <img src={registration} alt="food delivery boy image ....." />
        </div>
      </div>
    </div>
  );
};

export default Registration;
