import pizza from './Images/pizza.jpg';
import burger from './Images/burger.jpg';
import pastry from './Images/pastry.jpg';

export const DataArray = [
  {
    id:1,
    itemName: "Pizza",
    price: "100",
    about: "It is an onion cheese pizza",
    img: pizza
  },
  {
    id:2,
    itemName: "Burger",
    price: "120",
    about: "It is a beef burger",
    img: burger
  },
  {
    id:3,
    itemName: "Pastry",
    price: "50",
    about: "It is a chocolate pastry",
    img: pastry
  },
  {
    id:5,
    itemName: "Pastry",
    price: "50",
    about: "It is a chocolate pastry",
    img: pastry
  },
  {
    id:6,
    itemName: "Pastry",
    price: "50",
    about: "It is a chocolate pastry",
    img: pastry
  },
  {
    id:7,
    itemName: "Burger",
    price: "120",
    about: "It is a beef burger",
    img: burger
  },
  {
    id:8,
    itemName: "Burger",
    price: "120",
    about: "It is a beef burger",
    img: burger
  }
];
