import React, { useEffect, useState } from "react";
import "./Styles/Items.css";
import { DataArray } from "./Data";
import axios from "axios";
import { backendUrl } from "../backendUrl";
import ProductCart from "./ProductCart";
const Items = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [productList, setProductList] = useState([]);
  async function getProductList() {
    let res = await axios.get(`${backendUrl}/get/all/product`);
    if (res.status == 200) {
      console.log(res.data);
      setProductList(res.data);
    }
  }

  useEffect(() => {
    // getProductList();
  }, []);

  return (
    <div className="Items-Container">
      <div className="Items-Container-Seachbar">
        <input type="search" placeholder="search here ...." />
      </div>
      <div className="Items-Card-Container">
        {productList.map((item, index) => (
          <ProductCart productData={item} key={index} />
        ))}
      </div>
    </div>
  );
};

export default Items;
