import React, { useEffect, useState } from "react";
import OrderCard from "./OrderCard";
import { backendUrl } from "../backendUrl";
import axios from "axios";

const OrderHistory = () => {
  const [orderList, setOrderList] = useState([]);

  useEffect(() => {
    async function getOrderDetails() {
      try {
        let userId = JSON.parse(localStorage.getItem("user_info")).user._id;
        let res = await axios.get(`${backendUrl}/orders/${userId}`);

        if (res.status === 200) {
          setOrderList(res.data.orders);
          console.log(res.data.orders);
        }
      } catch (error) {
        console.error("Error fetching order details:", error);
      }
    }

    getOrderDetails();
  }, []);

  return (
    <div>
      <h2>Order History</h2>
      {orderList.map((order, index) => (
        <OrderCard key={index} order={order} />
      ))}
    </div>
  );
};

export default OrderHistory;
