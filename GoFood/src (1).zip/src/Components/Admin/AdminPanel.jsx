import React from "react";
import SideBar from "./SideBar";

const AdminPanel = () => {
  return (
    <div className="container">
      <div className="row">
        <SideBar />
      </div>
    </div>
  );
};

export default AdminPanel;
