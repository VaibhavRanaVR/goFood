export const backendUrl = "http://localhost:5500/api";
